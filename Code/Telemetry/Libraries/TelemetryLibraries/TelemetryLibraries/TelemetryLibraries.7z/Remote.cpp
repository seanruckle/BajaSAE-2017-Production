#include "Remote.h"



Remote::Remote()
{
}


Remote::~Remote()
{
}
