#pragma once
class SD
{
public:
	SD();
	~SD();
};

