#pragma once
class Remote
{
public:
	Remote();
	~Remote();
};

