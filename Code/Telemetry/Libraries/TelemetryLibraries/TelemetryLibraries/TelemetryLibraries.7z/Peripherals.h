#pragma once
class Peripherals
{
public:
	Peripherals();
	~Peripherals();
};

