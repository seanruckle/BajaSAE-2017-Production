#pragma once
class Sensors
{
public:
	Sensors();
	~Sensors();
};

