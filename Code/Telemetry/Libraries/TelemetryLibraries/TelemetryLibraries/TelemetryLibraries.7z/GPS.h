#pragma once
class GPS
{
public:
	GPS();
	~GPS();
};

