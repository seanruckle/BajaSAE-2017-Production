#include "Telemetry.h"



Telemetry::Telemetry()
{
}


Telemetry::~Telemetry()
{
}
