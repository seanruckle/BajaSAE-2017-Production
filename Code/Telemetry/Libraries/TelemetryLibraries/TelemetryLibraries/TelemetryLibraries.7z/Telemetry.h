#pragma once
class Telemetry
{
public:
	Telemetry();
	~Telemetry();
};

