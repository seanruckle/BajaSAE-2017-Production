#include "Display.h"



Display::Display()
{
}


Display::~Display()
{
}


// Set the display mode
void Display::setMode(unsigned char mode)
{
}


// Return current display mode
unsigned char Display::getMode()
{
	return 0;
}


// Set speed to display (Not the speed of the screen)
void Display::setSpeed(unsigned char speed)
{
}


// set turn signal direction
void Display::setSignal(unsigned char direction)
{
}


// perform any necessary setup
void Display::init()
{
}
