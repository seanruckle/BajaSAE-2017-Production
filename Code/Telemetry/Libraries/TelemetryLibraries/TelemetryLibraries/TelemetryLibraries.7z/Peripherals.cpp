#include "Peripherals.h"



Peripherals::Peripherals()
{
}


Peripherals::~Peripherals()
{
}
